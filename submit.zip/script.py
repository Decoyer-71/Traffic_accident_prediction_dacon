# script.py
import os, argparse, joblib
import numpy as np
import pandas as pd


# =======================
# 학습 때 사용한 전처리 유틸 (그대로)
# =======================


# 'Age'컬럼 시각화 및 데이터 활용을 위한 전처리
def convert_age_to_numeric(age_str):
    if isinstance(age_str, str) and len(age_str) > 1 :
        decade = int(age_str[:-1])
        group = age_str[-1]
        if group == 'a' : return decade + 2
        elif group == 'b' : return decade + 7
    try : return int(age_str)
    except (ValueError, TypeError) : return np.nan
    
def align_to_model(df, model):
    df_set = df.copy()
    df_set
    y = df_set['Label']



# =======================
# 학습 때 사용한 A/B 검사 전처리 (그대로)
# =======================
def preprocess_A(train_A):
    df = train_A.copy()
    print("Step 1: 전처리 및 사용컬럼 선정...")
    df['Age'] = df['Age'].apply(convert_age_to_numeric)
    
    print("Step 2: feature 생성...")
    df['A1-3'] = df['A1-3'].apply(lambda x : x.split(',').count('1'))
    df['A2-3'] = df['A2-3'].apply(lambda x : x.split(',').count('1'))
    df['A3-6'] = df['A3-6'].apply(lambda x : x.split(',').count('1'))
    df['A3-7'] = df['A3-7'].astype(str).apply(lambda x : round(np.mean([float(num)*0.001 for num in x.split(',')]), 2))
    df['A4-3'] = df['A4-3'].apply(lambda x : x.split(',').count('2'))
    df['A4-5'] = df['A4-5'].astype(str).apply(lambda x : round(np.mean([float(num)*0.001 for num in x.split(',')]), 2))
    df['A5-2'] = df['A5-2'].apply(lambda x : x.split(',').count('2'))

    return df


def preprocess_B(train_B):
    df = train_B.copy()
    print("Step 1: 전처리 및 사용컬럼 선정...")
    df['Age'] = df['Age'].apply(convert_age_to_numeric)

    print("Step 2: feature 생성...")
    df['B1-1'] = df['B1-1'].apply(lambda x : x.split(',').count('2'))
    df['B1-3'] = df['B1-3'].apply(lambda x : len([int(i) for i in x.split(',') if int(i) in (2, 4)]))
    df['B2-1'] = df['B2-1'].apply(lambda x : x.split(',').count('2'))
    df['B2-3'] = df['B2-3'].apply(lambda x : len([i for i in x.split(',') if int(i) in (2, 4)]))
    df['B3-1'] = df['B3-1'].apply(lambda x : x.split(',').count('2'))
    df['B3-2'] = df['B3-2'].apply(lambda x : round(np.mean([float(num) for num in x.split(',')]), 2))
    df['B4-1'] = df['B4-1'].apply(lambda x : len([int(i) for i in x.split(',') if int(i) in (2, 4, 6)]))
    df['B4-2'] = df['B4-2'].apply(lambda x : round(np.mean([float(num) for num in x.split(',')]), 2))
    df['B5-1'] = df['B5-1'].apply(lambda x : x.split(',').count('2'))
    df['B5-2'] = df['B5-2'].apply(lambda x : round(np.mean([float(num) for num in x.split(',')]), 2))
    df['B6'] = df['B6'].apply(lambda x : x.split(',').count('2'))
    df['B7'] = df['B7'].apply(lambda x : x.split(',').count('2'))
    df['B8'] = df['B8'].apply(lambda x : x.split(',').count('2'))
    df['B10-6'] = df['B10-6'].apply(lambda x : 20 - int(x))
    return df


# =======================
# 정렬/보정 (모델이 학습 때 본 피처 순서로)
# =======================
DROP_COLS = ["Test_id","Test","PrimaryKey","Age","TestDate"]

def align_to_model(X_df, model):
    feat_names = list(getattr(model, "feature_name_", []))
    if not feat_names:
        # fallback: 그냥 숫자형만
        X = X_df.select_dtypes(include=[np.number]).copy()
        return X.fillna(0.0)
    X = X_df.drop(columns=[c for c in DROP_COLS if c in X_df.columns], errors="ignore").copy()
    # 누락 피처 0으로 채움
    for c in feat_names:
        if c not in X.columns:
            X[c] = 0.0
    # 초과 피처 드롭 + 순서 일치
    X = X[feat_names]
    return X.apply(pd.to_numeric, errors="coerce").fillna(0.0)

# =======================
# main
# =======================
def main():
    # ---- 경로 변수 (필요에 따라 수정) ----
    TEST_DIR  = "./data"              # test.csv, A.csv, B.csv, sample_submission.csv 위치
    MODEL_DIR = "./model"             # 로지스틱 모델(base model) 저장 위치
    OUT_DIR   = "./output"
    SAMPLE_SUB_PATH = os.path.join(TEST_DIR, "sample_submission.csv")
    OUT_PATH  = os.path.join(OUT_DIR, "submission.csv")

    # ---- 모델 및 스케일러 로드 ----
    print("Load models...")
    model_A = joblib.load(os.path.join(MODEL_DIR, "logistic_model_A.pkl"))
    model_B = joblib.load(os.path.join(MODEL_DIR, "logistic_model_B.pkl"))
    print(" OK.")

    # ---- 테스트 데이터 로드 ----
    print("Load test data...")
    meta = pd.read_csv(os.path.join(TEST_DIR, "test.csv"))
    Araw = pd.read_csv(os.path.join(TEST_DIR, "./test/A.csv"))
    Braw = pd.read_csv(os.path.join(TEST_DIR, "./test/B.csv"))
    print(f" meta={len(meta)}, Araw={len(Araw)}, Braw={len(Braw)}")

    # ---- 매핑 ----
    A_df = meta.loc[meta["Test"] == "A", ["Test_id", "Test"]].merge(Araw, on="Test_id", how="left")
    B_df = meta.loc[meta["Test"] == "B", ["Test_id", "Test"]].merge(Braw, on="Test_id", how="left")
    print(f" mapped: A={len(A_df)}, B={len(B_df)}")

    # ---- 전처리 및 정규화 ----
    A_df = preprocess_A(A_df)
    B_df = preprocess_B(B_df)

    # ---- 피처 정렬/보정 ----
    XA = align_to_model(A_df, model_A)
    XB = align_to_model(B_df, model_B)
    print(f" aligned: XA={XA.shape}, XB={XB.shape}")

    # ---- 예측 ----
    print("Inference Model...")
    predA = model_A.predict_proba(XA)[:,1] if len(XA) else np.array([])
    predB = model_B.predict_proba(XB)[:,1] if len(XB) else np.array([])

    # ---- Test_id와 합치기 ----
    # ---- Test_id와 합치기 (dropna로 행이 제거되었을 수 있으므로, 처리 후의 df에서 Test_id를 가져옴) ----
    subA = pd.DataFrame({"Test_id": A_df["Test_id"].values, "prob": predA})
    subB = pd.DataFrame({"Test_id": B_df["Test_id"].values, "prob": predB})
    probs = pd.concat([subA, subB], axis=0, ignore_index=True)

    # ---- sample_submission 기반 결과 생성 (Label 컬럼에 0~1 확률 채움) ----
    os.makedirs(OUT_DIR, exist_ok=True)
    sample = pd.read_csv(SAMPLE_SUB_PATH)
    # sample의 Test_id 순서에 맞추어 prob 병합
    out = sample.merge(probs, on="Test_id", how="left")
    out["Label"] = out["prob"].astype(float).fillna(0.0)
    out = out.drop(columns=["prob"])

    out.to_csv(OUT_PATH, index=False)
    print(f"✅ Saved: {OUT_PATH} (rows={len(out)})")

if __name__ == "__main__":
    main()